To run UFO:

Open a terminal window.

$ cd this/directory
$ ufo
